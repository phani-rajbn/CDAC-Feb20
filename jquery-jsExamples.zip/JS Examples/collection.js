class Expense{
    constructor(id, desc, date, amount){
        this.id = id;
        this.desc = desc;
        this.date = date;
        this.amount = amount;
    }
}

class ExpenseManager{
    
    allExpenses = [];

    constructor(){
        this.addExpense(new Expense(111, "Flipkart purchase", new Date(2020, 7, 7), 1230));
        this.addExpense(new Expense(112, "Petrol", new Date(2020, 02, 7), 300));
        this.addExpense(new Expense(113, "Flipkart purchase", new Date(2020, 23, 4), 1000));
        this.addExpense(new Expense(114, "Flipkart purchase", new Date(2020, 13, 5), 5000));
        this.addExpense(new Expense(115, "Amazon Cart", new Date(2020, 2, 7), 10000));
    }

    addExpense = function(ex){
        allExpenses.push(ex);
    }

    findExpense = function(id){
        allExpenses.find(function(ex){
            if(ex.id == id)
                return ex;
        })
        
        throw "No Expense found for this ID";
    }

    updateExpense = function(ex){
        for (let index = 0; index < allExpenses.length; index++) {
            const element = array[index];
            if(element.id == ex.id){
                element.desc = ex.desc;
                element.date = ex.date;
                element.amount = ex.amount;
                return;
            }
        }
        throw "No Expense found to update"
    }
}