const addFunc = function(v1, v2){
    return v1 + v2;
}

const subFunc = function(v1, v2){
    return v1 - v2;
}

const mulFunc = function(v1, v2){
    return v1 * v2;
}

const divFunc = function(v1, v2){
    return v1 / v2;
}

const modFunc = function(v1, v2){
    return v1 % v2;
}
