function $(id){
    return document.getElementById(id);
}

function $click(id, func){
    $(id).onclick = func;
}

/* function $fade(element){
    let collection = document.getElementsByTagName(element);
    for(let i =0; i < collection.length;i++){
        collection[i].style.backgroundColor = 
    }
} */