//This program is created to work on Objects in JS...
const emp = {};//This is an object in JS. 
emp.empName = "Phaniraj";
emp.empAddress = "Bangalore";
emp.empSalary = 55000;
emp.empMobile = 9845205684;
emp.displayData = function(){
    const data = `The Name is ${emp.empName} from ${emp.empAddress} who can be contacted at ${emp.empMobile}`;
    //alert(data);
}
for(key in emp)
{
    const content = `The Key: ${key}\tThe Value: ${emp[key]}`;
    console.log(content);
}
//This kind of Object creation is called as Singleton object, in this case, U dont declare or define a class, rather U directly create an object using JS Object syntax and start adding members to it. Members include data members as well function members. 
console.log(emp);
emp.displayData();
document.write(JSON.stringify(emp) + "<br/>");
//function acts like a constructor to create an object using new operator...
const employee = function(name, address, salary, phone){
    this.empName = name;
    this.empAddress = address;
    this.empSalary = salary;
    this.empPhone = phone;
}
//empObj is an object or instance of the class called employee..
const empObj = new employee("Vinod", "Shimoga", 76000 , 2342343243);
//TO represent an object as a string: JSON.stringify
console.log("Object created using Old Syntax:" + JSON.stringify(empObj));
for(key in empObj)
{
    const content = `The Key: ${key}\tThe Value: ${empObj[key]}`;
    console.log(content);
}
document.write(JSON.stringify(empObj) + "<br/>");

//New syntax of class creation in ES6
class Customer{
    constructor(id, name, address){
        this.cstId = id;
        this.cstName = name;
        this.cstAddress = address;
    }
}

