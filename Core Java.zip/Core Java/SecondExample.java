//This example is used for basic IO operations in Java.....
//All the classes related to basic IO operations come under a group called java.io. The grouping of Java Classes for better management is called as package. package is similar to namespace of Cpp where we can group a bunch of classes based on conceptual grouping. 
import java.io.Console; 

//Console is an class used to perform Console based IO operations on the Console(Terminal). It contains the cfunctions to access string based COnsole IO. 
//NOTE: Console was added to the java libraries since Java 6. This class is used to read from and write to the console. It a convinient class for peforming Inputs and outputs on console. 
//Earlier we used to use System.out and System.in to do IO operations. 

//console class cannot be used with IDE like Eclipse as they are not designed for it. 
getNumber
public class SecondExample {
    static Console con = System.console();//Alias to the System.console() object
    public static void main(String[] args) {
        /* System.out.println("My name is Phaniraj");
        System.out.println("I am from Bangalore");
        System.out.println("I am a Computer Trainer");
        System.out.println("I like Farming as a hobby!!!"); */

        System.out.println("Enter the name");
        String name = con.readLine();

        con.printf("Enter the Address\n");
        String address = con.readLine();

        con.printf("The Name is %s from %s\n", name, address);

        
        /*
            readline is the method used to take input from the user as string.
            printf is the method used to print an output to the user. printf is similar to printf of C/C++
        */
    }
}