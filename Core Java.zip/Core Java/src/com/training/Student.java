package com.training;

import java.io.Serializable;

//This is a interface that is internally implemented by the Java Framework and U dont have to add any new methods to it.
public class Student implements Serializable {
	 int id;
	 String name;
	 int marks;
	
	public Student(int id, String name, int marks) throws Exception{
		
		if(id < 1) throw new Exception("ID cannot be 0 or a negative");
		this.id = id;
		this.marks = marks;
		this.name = name;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%d, %s, %d\n", id, name, marks);
	}
}
