package com.training;
import java.util.Date;
import java.util.InputMismatchException;
//Common file with custom functions for handling user inputs and display, will be used in all the Examples for User interactions
import java.util.Scanner;

public class MyConsole {	
	private static Scanner sn = new Scanner(System.in);
	static void print(Object data) {
		System.out.println(data);
	}
	
	static void printError(String msg) {
		System.err.println(msg);
	}
	//SImilar logic of what u see in printf in python
	static String getString(String question) {
		print(question);
		return sn.nextLine();
	}
	
	static int getNumber(String question) throws InputMismatchException {
			return Integer.parseInt(getString(question));
	}
	//Java 8 syntax of creating a date based on the user input
	static Date getDate() {
		int dd = getNumber("Enter the Day of the month");
		int mm = getNumber("Enter the Month as 0 to 11");
		int yyyy = getNumber("Enter the Year as yyyy");
		return new Date(yyyy, mm, dd);
	}
	static double getDouble(String question) {
		print(question);
		double res = sn.nextDouble();
		return res;
	}
	
}
