package com.training;
//Ex12 of Java Training on Custom Collections
//All collections are classes that implement an interface called Iterable.  This interface has methods to return an Iterator object that is used to iterate thru' the collection. Iteration means moving thru' the collection one after the other without going out of bounds which is done by the foreach statement. 
public class CustomCollection {

	static StudentManager mgr = new StudentCollection();
	public static void main(String[] args) {
		try {
			mgr.addStudent(new Student(123," Phaniraj", 455));
			mgr.addStudent(new Student(124," Vinod", 455));
			mgr.addStudent(new Student(125," JoyDip", 455));
			mgr.addStudent(new Student(126," Mahesh", 455));
			mgr.addStudent(new Student(127," Jimmy", 455));
			MyConsole.print("Iteration using foreach thro Iterator object");
			for(Student s : mgr) {
				MyConsole.print(s.id);
			}
			
			MyConsole.print("Iterating thro a for loop");
			for (int i = 0; i < mgr.count(); i++) {
				MyConsole.print(mgr.get(i).name);
			}
		} catch (Exception e) {
			MyConsole.printError(e.getMessage());
		}
	}
}
