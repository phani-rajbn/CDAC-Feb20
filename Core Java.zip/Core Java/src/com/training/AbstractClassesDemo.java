package com.training;
//7th Example on OOP called Abstract classes....
/*
 * Abstract classes are classes that have one or more methods that are not implemented and will allow the derived class or child classes to implement it. 
 * The methods that don't have the implementations are called abstract methods..
 * An abstract class is one that has at least one abstract method in it. This class has one or more methods that are not implemented, so the class is incomplete, and hence cannot be instantiated. 
 * 
 * */

abstract class BankAccount{
	protected int amount;
	
	public BankAccount(int amount) {
		this.amount = amount;
	}
	void Credit(int money) {
		amount += money;
	}
	
	void Debit(int money) {
		if(amount >= money)
			amount -= money;
	}
	
	int getBalance() { return amount;}
	
	abstract void calculateInterest();
	//This method does not have a body, it is not implemented.
	//The class becomes incomplete, and it cannot be instantiated..
	//It also implies that the child classes must implement the abstract methods, else even the child classes must be declared as abstract...
	 
}

//All accounts in the bank need to calculate interest, however they are specific to the individual account types,
class SBAccount extends BankAccount{
	
	public SBAccount(int amount) {
		super(amount);
	}

	@Override
	void calculateInterest() {
		int roi = 6;
		double quarter = 0.025;
		int interest = (int)(amount * roi * quarter);
		amount += interest;
	}
}

public class AbstractClassesDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount acc = new SBAccount(5000);
		acc.calculateInterest();
		MyConsole.print("The Current Balance: " + acc.getBalance());
	}

}
