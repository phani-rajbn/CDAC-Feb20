package com.training;
import java.util.*;

interface MyIteration{
	int count();
	Student get(int index);
}

//An interface can be derived from 2 interfaces at the same level, multiple inheritance thru' interfaces...
interface StudentManager extends Iterable<Student>, MyIteration{
	void addStudent(Student s);
	void deleteStudent(int id) throws Exception;
	void updateStudent(Student s) throws Exception;
	List<Student> getAllStudents();
	//Save the data to a disc or read the data from the disc.....
}

public class StudentCollection implements StudentManager {
	List<Student> students = new ArrayList<Student>() ;
	@Override
	public void addStudent(Student s) {
		students.add(s);		
	}

	@Override
	public void deleteStudent(int id) throws Exception {
		for (int i = 0; i < students.size(); i++) {
			Student temp = students.get(i);
			if(temp.id == id) {
				students.remove(temp);
				return;
			}
		}
		throw new Exception("Student not found to delete");
	}

	@Override
	public void updateStudent(Student s) throws Exception{
		for (int i = 0; i < students.size(); i++) {
			Student temp = students.get(i);
			if(temp.id == s.id) {
				temp.name = s.name;
				temp.marks = s.marks;
				return;
			}
		}
		throw new Exception("Student not found to update");
	}

	@Override
	public List<Student> getAllStudents() {
		return students;
	}

	@Override
	public Iterator<Student> iterator() {
		return students.iterator(); 
	}

	@Override
	public int count() {
		return students.size();
	}

	@Override
	public Student get(int index) {
		if(index >= students.size()) {
			throw new IndexOutOfBoundsException("Index is out of bounds.");
		}
		return students.get(index);
	}
}

/*
 * Create a Console Application that registers complaints related to Training. 
 * This App is called as Feedback manager. 
 * Ur menu should be read from the file
 * User credentials should be taken as valid user. 
 * Aggregation, OOP, Collections, File IO, Statements and Expressions, File I/O....
 * Exception handling, 
 * JDBC
 * MySql Database must be installed
 * */










