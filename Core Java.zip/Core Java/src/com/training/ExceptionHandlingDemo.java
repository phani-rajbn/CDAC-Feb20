package com.training;

import java.util.InputMismatchException;

//Ex 09 of OOP....
/*
 * Exceptions are a sp condition that occurs during the program execution where the program fails to take a decision to take it forward based on a scenario(File is not found, DB connection has failed) or an input that is provided by the user could not be evaluated. This also includes programmer error, hardware failures, resource management
 * try...catch...finally
 * throw and throws
 * All Exceptions raised by the program in Java are raised as objects of a class derived from Exception. The object has a method called getMessage() which contains the description about the Exception. 
 * Every try block must be followed by either catch or finally block or both.
 * However U could have multiple catch blocks. The Parent Exception should be the last catch block if U use it.  
 * If an exception has to be escalated to the caller of the method to handle it, U should re throw the exception in the declaration using throws followed by the name of the Exception the method throws. 
 * throw is used to raise the Exception within the code block of the function....
 * NullPointerException: when U try to access a null object in ur code: U must instantiate the object before using it...
 * ArithematicException: Raised when arithmetic operators have raised the exception.
 * InputMismatchException: Raised when the input string is not in the correct format...
 * ArrayIndexOutOfBoundsException: WHen U R accessing an element which is out of bounds in the array(Beyond the index of the array) 
 * */

class MyException extends Exception{
	//U have to create Constructors to do the job.....
	public MyException() {
		super();
	}
	
	public MyException(String msg) {
		super(msg);
	}
	
	public MyException(String msg, Exception innerEx) {
		super(msg, innerEx);
	}
}


public class ExceptionHandlingDemo {
	public static void main(String[] args){
		//tryCatchExample();
		//multipleCatchExample();
		try {
		customExceptionHandling();
		}catch(MyException ex) {
			MyConsole.printError(ex.getMessage());
		}
	}

	private static void customExceptionHandling() throws MyException {
		//code block
		//To raise the error...
		throw new MyException("Exception is raised");
		
	}

	private static void multipleCatchExample(){
			try {
				int v1 = MyConsole.getNumber("Enter the First Value");
				int v2 = MyConsole.getNumber("Enter the Second Value");
				MyConsole.print("The added value: " + (v1 + v2));
			} catch (InputMismatchException e) {
				MyConsole.printError("Input was wrong!!!!");
			}
	}

	private static void tryCatchExample() {
		try {
			int x = 0;
			int res = 123/x ;
			MyConsole.print("The value : " + res);
		}catch(ArithmeticException ex) {
			MyConsole.print(ex.getMessage());
		}catch(Exception genEx) {
			MyConsole.print(genEx.getMessage());
		}finally {
			MyConsole.print("Clean up of the Operation irrespective whether an Error occurs or not!!!");
		}
	}
}
