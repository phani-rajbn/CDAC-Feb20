package com.training;
//Sixth Example on OOP about Modifiers for class members.
/*
 * static modifier is one that is used on members where U want to access them very frequently in a program. 
 * The data for static members is initialized once and only once during the execution of a given program. 
 * The static data is shared among all the objects of the class, thereby giving the feel of a singleton object. 
 * U cannot have static constructors in Java.
 * static members need an object to call the instance members even if it is in the same class. However, instance members can call the static members within them.
 * To call the instance members from the static methods, U need to create an object of the class and call it thru' the object. 
*/

class TempClass{
	static int no;
	void normalFunc() {
		MyConsole.print("Accessible by objects of the class");
		staticFunc();
	}
	
	static void staticFunc() {
		TempClass cl = new TempClass();
		cl.normalFunc();
		MyConsole.print("Accessible thro name of the class");
	}
}
public class ModifiersExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TempClass cl1 = new TempClass();
		cl1.no = 123;
		
		TempClass cl2 = new TempClass();
		MyConsole.print("The Cl2's no is " + TempClass.no);//Gives the same result as object's version. 
	}

}
