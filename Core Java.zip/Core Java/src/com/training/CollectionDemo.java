package com.training;

import java.util.*;//Allows to access all the classes within the java.util package...
/*
 * Ex09
 *Arrays in fixed in size. Real time apps need to add, remove or update the data at runtime. So we need some additional data structures to store the data, and update it as and when we need
 *If U want to retrieve and store the data in a specific format or locations, U dont have that flexibility in Arrays of Java. 
 * Collections are an important part of the Java Application Development as it involves a lot of data structures that can be used to make a real time application. 
 * There are 2 version of the collections, generic and non generic versions. Our course focuses on Generic version only. Gernic version is similar to the STL of CPP. 
 * All Collection classes implement a set of interfaces to get a common set of APIs to perform the operations. All collections have an ability to add the elements, remove them and allow the collections to reorganize and fill the gaps. 
 * There are some important interfaces that are implemented by these collection classes, if U implement those interfaces, then UR class can also become a collection class. This is how U create custom collections. 
 * List, Set, Map are some of the important interfaces that are implemented by the collection classes. 
 * There are ready to use classes which are used for developing apps
 * ArrayList: Works similar to array where the data is added to the bottom of the List. However U can store duplicate data in it. 
 * HashSet: Works similar to ArrayList, but stores only unique data in it. It uses hashcode to check the uniqueness of the object
 * HashMap: Store the data in the form of key-value pairs. Similar to associate arrays in php and python. In this case, key is unique to the collections. Values can be extracted using keys similar to index of an array
 * Queue stores the data in the form of first in first out basis where U add the items to the bottom of the collection, u cannot insert or remove in between the collections.. 
 * First the Hashset compares the adding object with the current list using the hashcode If the object's hashcode does not match any of the existing elements hashcode, it simply adds the object into the collection. If the hashcode is same, it calls the equals methods to check the logic of equivalence to compare 2 objects. 
 * PS: If 2 objects return the same hashcode, it does not mean that they are equal, it only means that they are of the same type. 
 * */

class Employee{
	int empId;
	String empName;
	String empAddress;
	
	public Employee(int id, String name, String address) {
		empId = id;
		empName = name;
		empAddress = address;
	}
	
	@Override
		public int hashCode() {
			return Integer.hashCode(this.empId);
		}
	
	@Override
		public boolean equals(Object obj) {
			if(obj instanceof Employee) { //checks the type of the object 
				Employee temp = (Employee)obj;//Safe Unboxing ...
				return this.empId == temp.empId;
			}
			return false;
		}
}

//WE will make this a Custom Collection, so that we can use this object in a foreach statement.....
class EmployeeCollection{
	
}
public class CollectionDemo {

	public static void main(String[] args) {
		
		//arrayListExample();
		//hashsetExample();
		//hashsetOnObjects();
		//hashmapExample();
		//queueExample();
		
	}

	private static void queueExample() {
		//QUeue is more like an abstract class, U Need Classes derived from Queue in this case, LinkedList to store the data as a Queue. 
		Queue<String> cart = new LinkedList<String>();
		cart.add("Apples");
		cart.add("Mangoes");
		cart.add("PineApples");
		cart.add("Raw Mangoes");
		cart.add("Gauva");
		cart.add("Banana");
		MyConsole.print(cart);
		//To remove, we can remove only the first element from the collection..
		cart.remove();
		MyConsole.print(cart); 
		//Recent list of items U see in shopping websites, is based on Queue..
	}

	private static void hashmapExample() {
		//It stores pairs of collection in the form of key-value pairs. Key is unique data that identifies the value. U could use key to extract the value associated with that key...
		//All the reference types can be used as key, U cannot use int or any other primitive type as key in HashMap...
		Map<Integer, String> employees = new HashMap<Integer, String>();
		employees.put(1, "Phaniraj");
		employees.put(2, "Andrew");
		employees.put(3, "Segal");
		employees.put(4, "Puneet");
		employees.put(1, "Naren");
		MyConsole.print("The users: " + employees.size());
		
	}

	private static void hashsetOnObjects() {
		HashSet<Employee> employees = new HashSet<Employee>();
		employees.add(new Employee(111, "Phaniraj", "Bangalore"));
		employees.add(new Employee(112, "Krishna", "Bangalore"));
		employees.add(new Employee(113, "Robert", "Hassan"));
		employees.add(new Employee(111, "Shyam", "Mysore"));
		MyConsole.print("THe no of Unique employees are " + employees.size());
		for(Employee emp : employees)
			MyConsole.print(emp.hashCode());
	}

	private static void hashsetExample() {
		//Similar to the way Arraylist works, except it stores only unique values...
		HashSet<String> basket = new HashSet<String>();
		basket.add("Mangoes");
		if(basket.add("Mangoes"))  MyConsole.print("Added");
		else MyConsole.print("Already exists");
		basket.add("Mangoes");
		basket.add("Mangoes");
		MyConsole.print("The no of items in the basket is " + basket.size());
		//Rest of the operations are similar to that of ArrayList..
	}

	private static void arrayListExample() {
		ArrayList<String> data  = new ArrayList<String>();//Generic version of Arraylist which is type safe. 
		data.add("Apple");
		data.add("PineApple");
		data.add("CustardApple");
		data.add("Mango");
		data.add("Raw Mango");
		data.add("Orange");
		data.add("Nagpur Orange");
		MyConsole.print("The no of items in the collection: " + data.size());
		for(String item : data) MyConsole.print(item);
		data.remove(2);
		MyConsole.print("After removing!!!!");
		
		for(String item : data) MyConsole.print(item);
	}

}























