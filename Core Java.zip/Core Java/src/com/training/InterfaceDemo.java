package com.training;

//Ex08 
//methods are not to be implemented, but the class that inherits from this, must implement all the methods like a contract. 
//interface provides plan and implement mechanism.
//interface don't need the implementation logic, they only need on what needs to be done.
//How it needs to be done is managed by the implementor class. 
//Default methods in Interfaces, since Java 8 we have a feature where U can add an extra method within an interface that has functionality defined in it.

/*
 * Rules of Interface Programming. 
 * A class that implements the interface must implement all the methods of the interface with the same scope mentioned. 
 * U can have static methods in interfaces and will be implemented by the child classes. 
 * U can also have private methods with implementations in it. 
 * A Class can implement multiple interfaces at the same level like multiple inheritance..
 * */

interface DataComponent{
	void addRecord(int id, String name, String address, double salary);
	void updateRecord(int id, String name, String address, double salary);
	void deleteRecord(int id);
	Object getAllRecords(); 
	default Object findRecord(int id) {
		initialization();
		//This is new in Java 8 or later....
		return "The Data with Id is returned";
	}
	
	//Available only from Java 9, the main purpose is to share some common tasks among the non-abstract methods of the interface. 
	private void initialization() {
		MyConsole.print("This code will do some initialization for the interface");
	}
}

//Interfaces are implemented by the implementor classes, they are bound to a contract that says that all the methods of the interface must be implemented by the implementor class....
class MySqlDataComponent implements DataComponent{

	@Override
	public void addRecord(int id, String name, String address, double salary) {
		MyConsole.print(String.format("The name %s from %s with a salary of %f is added", name, address, salary));
		
	}

	@Override
	public void updateRecord(int id, String name, String address, double salary) {
		MyConsole.print(String.format("The name %s from %s with a salary of %f is updated", name, address, salary));
		
	}

	@Override
	public void deleteRecord(int id) {
		MyConsole.print(String.format("The Employee with id %d is deleted", id));
		
	}

	@Override
	public Object getAllRecords() {
		return new String [] {
			"Phaniraj", "Gopal", "Suresh", "Robert", "Louis", "Tom Hanks"	
		};
	}
	
}

public class InterfaceDemo {
	public static void main(String[] args) {
		DataComponent com = new MySqlDataComponent();
		com.addRecord(123, "Phaniraj", "bangalore", 45000);
		String [] records = (String[])com.getAllRecords();
		for(String name : records) MyConsole.print(name);
	}

}

//U can use final keyword on a class that makes the class non inheritable. OOP promotes Inheritance and reusability, so if U make this class as final it stops the features of OOP applicable to it. 
//final keyword applied to a variable makes it behave like a const...
//When applied to a method, the method is not overridable.
//When applied on the class, it will not be extendable. 















