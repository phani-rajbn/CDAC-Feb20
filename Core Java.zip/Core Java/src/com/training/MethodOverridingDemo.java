package com.training;

/*
 * Second Example
 * If a Base class has a method and U intend to modify that method based on the current requirement, U can redefine the methods in the Child class without changing the signature of the method. The non-changing feature is mandatory...
 * */

class Account{ //1997	
	public void withdraw() {
		System.out.println("The Amount can be withdrawn only during the business hrs from 10::00 to 13:00 hrs");
	}
}

class CoreBankingAccount extends Account {
	@Override //Annotations in Java is more like extended rules to be applied on the code...
	public void withdraw() {
		super.withdraw();//U R still using the older Version
		System.out.println("However, U could withdraw from our ATMs beyond Office hrs!!!");
	}
}

class AccountFactory{
	public static Account createAccount(String arg) {
		if(arg.equals("Old"))//Scanner it creates a new string
			return new Account();
		else 
			return new CoreBankingAccount();
	}
}
public class MethodOverridingDemo {

	public static void main(String[] args) {
		/*
		 * Account acc = new Account(); acc.withdraw();
		 * 
		 * //Same acc object is behaving in a different way! Same function is behaving
		 * differently...Poly forms is polymorphism is.... acc = new
		 * CoreBankingAccount(); acc.withdraw();
		 */
		//Method overriding is also called RUNTIME POLYMORPHISM...
		//The object type is determined dynamically at runtime as the object to which it is instantiated tells the behavior of that object..it is decided only when the program executes. 
		
		
		String type = MyConsole.getString("Enter the Type of Account: Old or New");
		Account acc = AccountFactory.createAccount(type);
		acc.withdraw();
	}

}







