package com.training;

import java.util.Date;

//This is Example 4 of the OOP Training
//Has a Relationship
public class AggregationDemo {

	public static void main(String[] args) {
		Customer cst = new Customer("Phaniraj", "RR Nagar, Bangalore", 3);
		cst.addItemToBill(new Item("Rice", 5, 55));
		cst.addItemToBill(new Item("Wheat", 5, 35));
		cst.addItemToBill(new Item("Oil", 5, 155));
		MyConsole.print("All the items are added, now the total billing");
		int totalAmount = cst.currentBill.CalculateBill();
		MyConsole.print("Please Pay : " + totalAmount);
	}

}


class Customer{
	String cstName;
	String cstAddress;
	Bill currentBill; //This is called as Aggregation, where an object of another class will become a property of the current class. 
	
	public Customer(String name, String address,int noOfItems) {
		cstName = name;
		cstAddress = address;
		currentBill = new Bill(noOfItems);
	}
	
	public boolean addItemToBill(Item item) {
		for (int i = 0; i < currentBill.items.length; i++) {
			if(currentBill.items[i] == null){
				currentBill.items[i] = new Item(item);
				return true;
			}
		}
		return false;		
	}
}

class Bill{
	
	public Bill(int noOfItems) {
		items = new Item[noOfItems];
	}
	Date date;
	double amount;
	Item [] items;
	public int CalculateBill() {
		int totalAmount = 0;
		for (Item item : items) {
			totalAmount += item.totalBill;
		}
		return totalAmount;
	}
}
//Student has address which internally has Address1, Address2, Street, City, State..
//Book has author who has properties like Name, Qualification, Age, FirstBook, LastBook.
class Item{
	String name;
	int quantity;
	int unitPrice;
	int totalBill;
	
	public Item(String name, int quantity, int price) {
		this.name = name;
		this.quantity = quantity;
		this.unitPrice = price;
		this.totalBill = unitPrice * quantity;
	}
	
	public Item(Item item) {
		name = item.name;
		quantity = item.quantity;
		unitPrice = item.unitPrice;
		this.totalBill = item.totalBill;
	}
}
/*
 * Aggregation means HAS-A relationship. If U want a class to hold an object of an another class, we can create the class's object as a property for the class
 * */
