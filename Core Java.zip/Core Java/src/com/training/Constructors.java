package com.training;
//This is Example 5 of the OOP Training

/*
 * Constructor is a sp method that is used to provide the dependencies for the object creation. 
 * Dependencies are the inputs given to create a successful object. 
 * Constructors have the same name as the class name in which it is declared. It must not have any explicit return type. 
 * U can have as many no of constructors U want within a class to provide flexibility in creating the object.
 * Constructors are invoked when the object is instantiated using new operator. 
 * Constructors that don't take args are called default constructors else they are called parameterized constructors. 
 * If there is base class for the current class, implicitly base class's default constructor will be called.
 * If the base class does not have the default constructor, U must call it using super which infers to the immediate base class. 
 * If U dont want an object to be created by the user, U could mark the constructor as private.  private constructors are created for 2 reasons : If UR class has only static methods and U dont need object for it; else U want a single object across the program and no 2 instances should be created.  
 * */
public class Constructors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cake plainCake = new Cake();
		MyConsole.print(plainCake);
	}

}

class Cake{
	String title;
	int size;
	String shape;
	String flavor;
	
	public Cake() {
		this("Owner", 2, "Circle", "Vanilla");//calling another constructor from one...
		
	}
	
	public Cake(String towhom, int size, String shape, String flavor) {
		this.title = towhom;
		this.shape = shape;
		this.flavor = flavor;
		this.size = size;
	}
	
	@Override
	public String toString() {
		return String.format("Ordered For:%s\nShape: %s\n", this.title, this.shape);
	}
}