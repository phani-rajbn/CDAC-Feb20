package com.training;


import java.io.*;
//Serialization is a process of persisting the data to a storage device like memory, file and cross processes.
//Serialization is not about file io. it is saving the object itself, not the data of the object. object contains info about the data, its members, package info and many other details that are helpful in IPC interactions.
//In this case, the state of the object is converted into bytestream and pushed to memory or a file. The file not only contains the data but also the type info about that object so that it is retrievable to the same state from which it was serialized. 
//The process of converting object to a saved state is called Serialization and the retrieval of the saved state to an object is called DeSerialization. 
//There is no concept of appending data like File IO in serialization.
//Any object of a class that implements Serializable can be serializied.
public class SirealizationDemo {

	public static void main(String[] args) {
		String choice = MyConsole.getString("Save or Load");
		if(choice.toLowerCase().equals("save"))
			serializationDemo();
		else
			deserializationDemo();
	}

	private static void deserializationDemo() {
		try {
			FileInputStream fs = new FileInputStream("Demo.ser");
			ObjectInputStream os = new ObjectInputStream(fs);
			Student s = (Student)os.readObject();
			if(s   == null)
				throw new Exception("No data is stored in serialization");
			MyConsole.print(s);
			os.close();
		} catch (Exception e) {
			MyConsole.printError(e.getMessage());
		}
	}

	private static void serializationDemo() {
		try {
			Student student = new Student(1111,"Phaniraj", 400);
			FileOutputStream fs = new FileOutputStream("Demo.ser");
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(student);;
			os.close();
		} catch (Exception e) {
			MyConsole.printError(e.getMessage());
		}
	}
}
