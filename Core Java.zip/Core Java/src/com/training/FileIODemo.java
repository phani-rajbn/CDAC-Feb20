package com.training;

import java.io.*;
import java.util.*;

/*
 * Java iO is used to perform IO operations on storage devices like files and memory...
 * Java uses Streams to perform the operations. Anything that comes inot the application is called as INPUT Stream and anything that goes out of the application is called as the OUTPUT Stream
 * Stream is a sequence of data that flows from one end(Source) to another end(Destination)
 * Streams are composed of bytes. All are bytes in Java IO, reading the file and reading the image is the same. However the data in the images will be huge and so we call them as BLOB(Binary large objects). 
 * 3 Streams in Java: input(System.in), output(System.out) and err(System.err). in and out are the std inputs and outputs of any Java application. err becomes the std error stream where the application is about to get terminated.
 * Most of the streams are derived from 2 abstract classes: 
 * InputStream->FileInputStream, BufferedInputStream, ObjectInputStream, DataInputStream
 * OutputStream->FileOutputStream, BufferedOutputStream, ObjectOutputStream, DataOutputStream   
 * */
//Ex10 for File IO operations
public class FileIODemo {

	public static void main(String[] args) {
		try {
			//basicIOExample();
			filewritingDemo();
			//filereadingDemo();
			//csvReadingExample();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			MyConsole.printError(e.getMessage());
		}
		
	}
	
	private static void csvReadingExample( )throws Exception {
		//The improvised version of file reader is the bufferedreader which contain additional apis that can be performed on Text based files. The reading process or the writing process will first be written to a buffer memory and then transfered to the destination. In this case, there will be no latency in the writing or reading process, this is helpfull for read/write larger streams of data...
		ArrayList<Student> students = new ArrayList<Student>();
		String filename = "Sample.txt";
		FileReader reader = new FileReader(filename);
		BufferedReader bReader = new BufferedReader(reader);
		String line = "";
		while((line = bReader.readLine()) != null) {
			//Split the line....
			String [] words = line.split(",");
			int id = Integer.parseInt(words[0].trim());
			int marks = Integer.parseInt(words[2].trim());
			String name = words[1];
			Student s = new Student(id, name, marks);
			students.add(s);
		}
		bReader.close();
		for(Student s : students)
			MyConsole.print(s);
	}

	private static void filereadingDemo() throws IOException {
			FileReader reader;
			try {
				reader = new FileReader("Sample.txt");//Slow as it reads each character at a time...
				int index =0;
				while((index = reader.read()) != -1) {
					System.out.print((char)index);
				}
				reader.close();
			}catch(FileNotFoundException fEx) {
				MyConsole.printError("File not found to read");				
			}catch(IOException genEx) {
				MyConsole.printError(genEx.getMessage());
			}
		
	}

	private static void filewritingDemo() throws IOException, Exception{
		//For working with text based files, U could use a Class TextWriter specifically designed for writing text based data...
		FileWriter writer = new FileWriter("Sample.txt", true);
		int id = MyConsole.getNumber("Enter the ID of the student");
		String name= MyConsole.getString("Enter the name of the Student");
		int marks = MyConsole.getNumber("Enter the marks scored by the student");
		//String data = String.format("%d, %s, %d\n", id, name, marks);
		Student s = new Student(id, name, marks);
		writer.write(s.toString());
		writer.close();
	}

	private static void basicIOExample() throws IOException {
		//Using java builtin IO objects
		System.out.println("Simple message on the std output device(Console)");
		System.err.println("OOPS! Something wrong happened");
		System.out.print("Press any key in the keyboard");
		int value = System.in.read();
		System.out.println(String.format("The Ascii value :%d\tThe char value: %s", value, (char)value));
	}

}
