
public class ObjectDemo {
    public static void main(String[] args) {
        // firstExample();
        secondExample();
        thirdExample();
    }

    private static void thirdExample() {
        //getClass Method used to get the Type info about the object.... 
        Object value = new Employee(123, "Phaniraj");
        Class detail = value.getClass();//Similar to typeof in Javascript.....
        System.out.println("The Class to which this variable belongs is " + detail.getName());
    }

    private static void secondExample() {
        //How to use the equals method of the object...
        // int fValue = 123;
        // int SValue = 123;
        // System.out.println(fValue == SValue);
        
        // String name = "Phaniraj";
        // String copyname = "Phaniraj";
        // System.out.println(name == copyname);//The 2 objects are eqaual. Its equivalance is checked implicitly using equals method....
        // if(name.equals(copyname))
        //     System.out.println("They are equal");
        // else
        //     System.out.println("They are not equal");

        Employee emp1 = new Employee(123, "Phaniraj") ;
        Employee emp2 = new Employee(123, "Phaniraj") ;
        //Employee emp2 = emp1 ;
        System.out.println(emp1.equals(emp2));//true if we modify the equals method of the Employee class....
        System.out.println("The object : " + emp1.toString());
        System.out.println("The object : " + emp2.toString());

    }

    private static void firstExample() {
        //Boxing and Unboxing Feature....
        int x = 123;
        String stringValue = Integer.toString(x);
        int hashcode = Integer.hashCode(x);
        
        System.console().printf("The String value is %s and its hashcode is %d\n", stringValue, hashcode);//hashcode will be the value of the variable...

        Object obj = 123;//Similar to let of JS where the variable will implicitly hold the data type of the value that is uset...
        //In this case, the 123 is boxed into the Object obj. BOXING is a feature where any variable will be assigned to an Object variable and the data gets hidden in it. 
        //For any operations U wish to do, it should be UNBOXED....
        int temp = (int)obj;//IN this case, the obj is cconverted to int....This is called as UNBOXING!!!!
        temp++;
        temp = temp + 234;
        System.out.println("The value after all the unboxing and modifying: " + temp);
        obj = temp;//Assign it back to object. 
    }

}

class Employee{
    public int empID;
    public String empName;

    public Employee(int id, String name) {
        this.empID = id;
        this.empName = name;
    }

    @Override
    public boolean equals(Object obj){
        Employee temp = (Employee)obj;//UNBOX...
        return temp.empID == this.empID;
    }
}
/*
    Object is the universal data type of Java. Every thing U create and use is an object. 
    Object is defined in java.lang package. All data types in java are inherited from Object class. 
    It has common set of operations that are available for all the variables and members in a java program.
    Some of the common functionatlies:
    toString(): Convert an object to a string representation...
    equals(): Used to compare the object with another passed as argument. 
    getClass(): Used to extract the type info about the object. This gives the Wrapper class or the reference of the class U R Using...
    hashCode(): returns the hashvalue of the object, for every object U create, the JVM will create an ID called hashCode. This no is distinct for distinct objects. JVM uses its own alogithm to generate the hashcode for an object. If 2 objects share the same hashcode, it means that they are of the same type. For primitive types, hashcode would be the value of the variable. 
    finalize(): Similar to Destructor on C++. It is called when the object is being destroyed by the Garbage collector.. 

*/