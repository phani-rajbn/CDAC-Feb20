public class Common {
    //They are default.....
    static String getString(String question){
        System.out.println(question);
        return System.console().readLine();
    }

    //They are default.....
    static int getNumber(String question){
        System.out.println(question);
        String answer = System.console().readLine();
        int num = Integer.parseInt(answer);
        return num;
    }

    
    //They are default.....
    static double getDouble(String question){
        System.out.println(question);
        String answer = System.console().readLine();
        double num = Double.parseDouble(answer);
        return num;
    }

    //They are default.....
    static void print(String content){
        System.out.println(content);
    }
    
}