public class AccessSpecifiers {

    private static Account createAccount(){
        Account acc = new Account();
       int id = Common.getNumber("Enter the ID of this Account");
       String name = Common.getString("Enter the name of the Account holder");
       double balance = Common.getDouble("Enter the balance for this account");

       acc.setDetails(id, name, balance);
       return acc;
    }

    private static boolean processMenu(Account acc){
            printConsole();
            String answer = Common.getString("");
            switch(answer){
                case "1":
                    double amount = acc.getBalance();
                    Common.print("UR Current Balance: " + amount);
                    return true;
                case "2":
                    String details = acc.toString();
                    Common.print(details);
                    return true;
                case "3":
                case "4":
                    Common.print("Do it URSELF!!!!!!");
                    return true;
                default:
                return false;
            }          
    }
    public static void main(String[] args) {
       Account acc = createAccount();
       boolean processing = true; 
       do {
              processing = processMenu(acc);
        } while (processing);
        // Common.print("Thanks for Using our App!!!!");
        // Common.print("Bye!!!!");
    }

    private static void printConsole(){
        Common.print("~~~~~~~~~~~~~~Account Maintainance~~~~~~~~~~~~~~~~~~~~~");
        Common.print("To Check the Balance Press 1");
        Common.print("To Get Account Details Press 2");
        Common.print("To Credit amount Press 3");
        Common.print("To Debit amount Press 4");
        Common.print("PS: Any other key is considered as EXIT....."); 
    }
}
/**Access Specifiers
 * Java is Object Oriented Programming language which means that UR program is more focussed around classes and its objects....
 * OOP gives lots of features: Data Hiding..
 * Members in the class can be hidden to the outside entities of the program. As a programmer and designer U could decide which data U wish to hide and other data U wish to allow access. This feature is called ENCAPSULATION. 
 * Typically functions are created in a modular manner. These functions are cut into small pieces and will be used to make up the whole App. 
 * Encapsulation has different levels:
 * Within the class: private members, means the function or the member of the class will be prefixed with private while we declare the member in the code.
 * default: No keyword is available, however these members are available within the conceptual unit called package. 
 * Within the family: protected members: These are classes and its derived classes(Inheritance feature of OOP)
 * Anywhere and everywhere: public members which are prefixed with public keyword.
 * If no access specifier is mentioned, they are default, means available within the package, if no package is mentioned, it will be under global package. 
 * PS: Package is a conceptuall grouping of classes to avoid naming conflicts. They are similar to namespaces of C++. 
 */