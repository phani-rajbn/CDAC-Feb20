public class ClassesAndObjects {
    public static void main(String[] args) {
        createObjectDemo();
    }

    private static void createObjectDemo() {
        //Class is used only when U create an object out of it..
        Account acc = new Account();//The object is created and memory is allocated here.....
        acc.setDetails(123, "Phaniraj", 45000);
        acc.CreditAmount(4500);
        acc.DebitAmount(300);
        System.out.println("The Current balance : " + acc.getBalance());
        
        System.out.println("The String representation of Account object is " + acc.toString());
    }
}
/*
What is a Class? It is a user defined data type which would compose data of multiple datatypes to represent a real world entity.
Class can not only have data members, but also have member functions. functions are typically created to manipulate the data of the class's object. 
The data will be usually hidden thro ENCAPSULATION and methods provide the functionalities to manipulate the hidden data. 

*/
class Account{
    private String holderName;
    private double balance;
    private int accNo;

    public void setDetails(int id, String name, double balance){
        holderName = name;
        accNo = id;
        this.balance = balance; //this represents the current object of the class on which these operations are done with...
    }

    public void CreditAmount(double amount){
        this.balance += amount;
    }
    public void DebitAmount(double amount){
        if(this.balance >= amount)
            this.balance -= amount;
        else
            System.out.println("Insufficient Funds!!!!");
    }

    public double getBalance() {
        return this.balance;
    }

    public String getName() {
        return this.holderName;
    }

    public int getAccno(){
        return this.accNo;
    }

    public String toString(){
        String display = "\nAccount No: " + this.accNo;
        display += "\nHolder Name: " + this.holderName;
        display += "\nBalance Amount: " + this.balance;
        return display;
    }

}//Definition for the class, no memory is created in the program. 