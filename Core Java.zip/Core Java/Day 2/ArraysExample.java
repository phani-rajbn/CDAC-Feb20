/**
 * ArraysExample
 */

public class ArraysExample {
    public static void main(String[] args) {
       //firstExample();
       //secondExample();
       //thirdExample();
       //fourthExample();
       //fifthExample();
    }
   

    private static void fifthExample() {
        //Array of arrays is called jagged array. It will have a fixed no of rows and variable no of columns in each row...
        //A School is an array of classrooms where each class has a variable no of students in it....
        //A database is a collection of tables and each table has variable no or rows and columns in it....
        int [][] school = new int[4][];//It has 4 rows and each row has an independent array with its own size....
        school[0] = new int[]{55,66,44,56,67,77};
        school[1] = new int []{67,56,44,56};
        school[2] = new int[]{66,77,87,89,87,67,56,45,56};
        school[3] = new int [] {66,76,56,45,45,45,56,67,87,98,49};

        for (int i = 0; i < school.length; i++) {//It gives the no of rows(Class rooms)
            for (int score : school[i]) {
                System.out.print(score + " ");
            }
            System.out.println();            
        }
    }

    private static void fourthExample() {
        //Use multi Dimensional Array...
        int [] [] marks = {{65,66,77,87,67}, {55,36,67,97,47} , {63,68,71,84,61}, {56,78,77,55,67}, {36,89,90,97,97}}; //5X5
        
        //Display all the students score in a tabular columns....
        for (int i = 0; i < 5; i++) {
            System.out.print("Student " + (i + 1) + ":");
            for (int j = 0; j < 5; j++) {
                System.out.print(marks[i] [j] + " ");
            }
            System.out.println();
        }
    }

    private static void thirdExample() {
        //How to use for each syntax in Java, it is available since Java 5.0 and another syntax....
        String [] names = {"Phaniraj", "Krishna", "Gopal", "Ram", "Robert"};//no need for new keyword in Java if U R placing the values directly.....
        for (String value : names) {
            System.out.println(value);
        }
        /* 
            foreach is  forward only and readonly. U cannot use this for setting the values of the elements in the array. It is used for reading the data. 
            U dont need to know the bounds of the array, as UR iteration will always be within the bounds of the array....
            It is forward only, unlike for loop which will allow to even iterate backwards.....
            foreach is used only on arrays and collections, not on other kind of data
        */
    }

    static void secondExample() {
        String [] names = new String[5]; //Another syntax of crweating array in Java....
        int index = 0;
        do {
            System.out.println("Enter a string value for the array!!!");
            names[index] = System.console().readLine();
            index++;
        } while (index < 5);

        System.out.println("All the values are set, lets read them!!!!!");
        for(int i =0; i < 5; i++) System.out.println(names[i]);
    }

    static void firstExample() {
        final int size = 5;//const in Java...
        int values[];//Syntax of creating array in Java. 
        values = new int[size];//Instantiating the array....

        for (int i = 0; i < size; i++) {
            values[i] = i + 1;
        }

        for (int i = 0; i < size; i++) {
            System.out.println(values[i]);
        }
    }
} 
/*
Points to remember:
Arrays are refernece types. They are allowcated dynamically. 
All arrays are instances of a class called Array defined in java.lang package. 
WIth Array object, U get common functions that are used to manipulate the array data and get info about the data. 
Array index in Java starts with 0, U cannot change the loswer bound vakue of the array., 
length is the property of the array class used to get the size of the array. 
if the size of the array is determined at compile time, U should create a final value and use that as the size of the array....
arrays are fixed in size, U dont have any functions to add and remove the elements of the array without altering the other elements, Arrays are immutable. 
U should use collections for dynamic arrays in Java. 
*/