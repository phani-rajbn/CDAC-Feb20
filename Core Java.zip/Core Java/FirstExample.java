public class FirstExample{
    public static void main(String[] args) {
        System.out.println("Hello world from Java!!!");
        //U will use a builtin Java class called System that provides an output stream object called out on which U wish to print a line of text called hello world. 
        //stream is a feature of allowing multiple sets of data to flow from a source to a destination. 
    }
}

/*
Download java from https://www.java.com/ES/download/
Rules of creating a Class in Java:
A File is recommended to have only one Java class and it should be public. 
If a File has multiple Java classes in it, that class which should contain the entry point must have the same name as the filename and it should be public. 
If a class is not marked as public, then it is taken as default which means that it is accessible only within a conceptual group called package. 

-----------------------------main Function------------------------------------------
main is the entry point of the program U wish to execute, the class loader looks for this entry point and the class that holds it. For this reason, the classname of the entry point and the filename should be same. 
In Java, the main function returns void, it must be public and static. 
main is not a global method. It is inside a class, so U should ensure that the method be called without creating an object of the class. if the method is static, the Execution Environment will call the method thro its classname. So the entry point method must be static.
It will take a String array as arg. U cannot have any other type as arg for the main function. Args of the main is to access the Commaond line args for the program...
It is recommended to group UR statements into small functions so that it is well organized.

*/