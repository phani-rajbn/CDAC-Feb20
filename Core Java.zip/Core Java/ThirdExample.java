//Program on Data types.
/*
Java has 2 type of data: Primitive types and Non-Primitive types. Primitive types are also called as VALUE Types:
integral types: byte(8), short(16), int(32), long(64)
floating: float(Single) and double(Double)
other types: char, boolean.

Most of the primitive types have Wrapper class that helps in performing conversion operations on those types. Integer is a wrapper class used to perform Integral operations on Integers.
All the wrapper arel defined under a package called java.lang
Similarlly we have it for all the primitive types. However, many have common functions:
valueOf: Is used to get the Wrapper object for a give string..
parseXXX: Used to convert a string to its type
toString: Used to convert the value to a string.
xxxValue: Get the primitive part of the given Wrapper object...

Non-primitive types include Arrays, classes, strings, interfaces.....
Non primitive types store the values in the heap area of the JVM Memory....
They memory is managed by the Garbage collector of JVM...
*/ 

import java.io.Console;


public class ThirdExample {
    static Console con = System.console();

    public static void main(String[] args) {
        // con.printf("Enter the age");
        // String answer = con.readLine();

        // //Integer is a class in Java used to perform int related operations in Java programs.
        // int age = Integer.parseInt(answer);
        
        int myAge = Prompt.getNumber("Enter the Age");
        con.printf("U R going to retire after " + (45-myAge) + "years");
    }
}

class Prompt{
    private static Console con = System.console();
    
    static String getString(String question){
        con.printf(question);
        return con.readLine();
    }

    static int getNumber(String question){
        return Integer.parseInt(getString(question));
    }
}