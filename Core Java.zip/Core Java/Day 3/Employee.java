
public class Employee {
    private int empId;
    private String empName;
    private String empAddress;
    private double empSalary;

    public Employee(int id, String name, String address, double salary) {
        empId = id;
        empName = name;
        empAddress = address;
        empSalary = salary;
    }    

    public String getName(){
        return empName;
    }
    
    public String getAddress(){
        return empAddress;
    }
    public int getId(){
        return empId;
    }
    public double getSalary(){
        return empSalary;
    }
    
    public String toString(){
        String data = String.format("The Employee ID: %d\nThe Employee Name: %s\nThe Employee Address: %s\nThe Employee Salary: %f\n\n", empId, empName, empAddress, empSalary);
        return data;
    }
}