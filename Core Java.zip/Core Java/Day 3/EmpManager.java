public class EmpManager {
    //This will interact with the data having all the CRUD operations required for UR Application needs...
    private final int no = 100; //This will not change...
    private Employee [] employees = new Employee[no];
    //It creates 100 employee objects all of them initialized to null.....
    //employees.length will be evaluated everytime U call it....
    public boolean addEmployee(Employee emp){
        for (int i = 0; i < no; i++) {
            if(employees[i] == null){
                int id = emp.getId();
                String name = emp.getName();
                String address = emp.getAddress();
                double salary = emp.getSalary();
                employees[i] =new Employee(id, name, address, salary);
                return true; //exit the function after insertion is done
            }
        }
        // Common.print("No Employee could be added here!!!!");
        return false;
    }

    public boolean deleteEmployee(int id){
        //iterate thro the collection...
        for (int i = 0; i < no; i++) {
            //find the first occurance of non-null employee whose id is matching..
            if((employees[i] != null) && (employees[i].getId() == id)){
                employees[i] = null;//U cannot explicit delete an object in Java.  
                return true;  
            }    
        }
        //Common.print("No Employee found to delete!!!");
        return false;
        //reset the loccation to null...
        //exit the function
        //Else continue the iteration till the end, and display error message...
    }

    public void updateEmployee(Employee emp){
        Common.print("Do IT UR SELF!!!!");
    }

    public Employee findEmployee(int id){
        for (Employee employee : employees) {
            if((employee != null) && (employee.getId() == id)){
                return employee;
            }
        }
        return null; 
    }

    public Employee [] getAllEmployees(){
        return employees;
    }

}