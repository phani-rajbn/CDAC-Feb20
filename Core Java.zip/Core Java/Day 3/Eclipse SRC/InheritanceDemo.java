/**
 * 
 */
package com.training;

/**
 * Open Closed Principle: A Class is open for extension but closed for modification. 
 * Once the class is created and exposed to the client, it is immutable. U cannot change the functionality or add new functionality to those classes. 
 * U can extend the class to another class thru' a feature of OOP called as INHERITANCE.
 * Any new feature that U wish to add to the class is done by extending the class to another and add those features to the new class.
 * The class that extends is called as the base class(Parent) and the class that is created to extend is called derived class(Child). 
 * U can also modify the existing functions of the parent class using method overriding. In this case, the method signature(return type, name of the function and its parameters) will be retained as it is in the parent class.  
 * In Java, we have single inheritance. U can inherit from only one class at a time. A class can have only one parent class at any level
 * However, U can have multi-level inheritance where class A is extended to class B and B is further extended to C. C has the features of both A and B in it. 
 * extends is used to inherit the class into the current class...
 * 
 * PS: A Class which has multiple base classes at any given level is called Multiple Inheritance which is found in C++. It has lot of problems, so newer languages that are based on C++ have either removed or replaced it with multi level inheritance. 
 */
public class InheritanceDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Some content on the Console");
		//BaseClass cls = new BaseClass();
		//cls.testFunc();
		
		DerivedClass tst = new DerivedClass();
		tst.testFunc(); //Parent lass methods
		tst.newTestFunc();//Current class methods...
				
	}

}
class BaseClass{
	public void testFunc() {
		System.out.println("Test Func from the base class");
	}
}


class DerivedClass extends BaseClass{
	public void newTestFunc() {
		System.out.println("Newwer version of the Test Func!!!");
	}
}