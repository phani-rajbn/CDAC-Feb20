package com.training;

import java.util.Scanner;

public class MyConsole {
	
	private static Scanner sn = new Scanner(System.in);
	static void print(Object data) {
		System.out.println(data);
	}
	
	static String getString(String question) {
		print(question);
		return sn.nextLine();
	}
	
	static int getNumber(String question) {
		print(question);
		int res = sn.nextInt();
		return res;
	}
	
	static double getDouble(String question) {
		print(question);
		double res = sn.nextDouble();
		return res;
	}
	
}
