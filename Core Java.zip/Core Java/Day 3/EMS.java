public class EMS {

    private static String menu = "";
    private static boolean processing = true;
    private static EmpManager manager = new EmpManager();
    private static void createMenu(){
        menu = "~~~~~~~~~~~~~~~~~~~~~~EMPLOYEE MANAGEMENT SYSTEM~~~~~~~~~~~~~~~~~~~~~~~~~\n";
        menu += "TO ADD NEW EMPLOYEE----------------->PRESS A\n";
        menu += "TO DELETE EMPLOYEE------------------>PRESS D\n";
        menu += "TO UPDATE EMPLOYEE------------------>PRESS U\n";
        menu += "TO FIND AN EMPLOYEE----------------->PRESS F\n";
        menu += "PS: ANY OTHER KEY IS CONSIDERED AS EXIT..................................";        
    }
    public static void main(String[] args) {
        createMenu();
        do{
            String choice = Common.getString(menu);
            processing = processMenu(choice);
        } while(processing);// Expected to execute atleast once.... 
    }

    private static boolean processMenu(String choice) {
        switch(choice){
            case "A":
                onAddingEmployee();
                return true;
            case "D":
                onDeletingEmployee();
                return true;
            case "U":
            return true;
            case "F":
                onFindingEmployee();
                return true;    
        }
        return false;
    }

    private static void onFindingEmployee() {
        int id = Common.getNumber("Enter the ID of the Employee to find....");
        Employee emp = manager.findEmployee(id);
        if(emp == null){
            Common.print("Employee not found with this id");
            return;
        }
        Common.print(emp.toString());    
    }

    private static void onDeletingEmployee() {
        int id = Common.getNumber("Enter the ID of the Employee to delete:");
        if(manager.deleteEmployee(id))
            Common.print("Employee with ID " + id + " deleted successfully!!!");
        else
            Common.print("No Employee found to delete!!!");
    }

    private static void onAddingEmployee() {
        //take the inputs from the user
        int id = Common.getNumber("Enter the ID of the Employee");
        String name = Common.getString("Enter the Name");
        String address = Common.getString("Enter the Address");
        double salary = Common.getDouble("Enter the Salary for this employee");
        //create an employee object
        Employee emp = new Employee(id, name, address, salary);
        //call the addEmployee method of the manager...
        if(manager.addEmployee(emp))
            Common.print("Employee added successfully");
        else
            Common.print("No Employee could be added here!!!!");        
    }
}