import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})

//A Component is a type script class which has a decorator called @Component which links other files into this Class
//For initialization of the data, U could use an interface called OnInit which has a function called ngOnInit() which must be implemented by our component. 
export class CalcComponent{
   //U need 4 variables: first, second, operand, result
   //function to process the operation. 
   firstValue : number = 13;
   secondValue : number = 12;
   operand : string = "X";
   result : number = this.firstValue + this.secondValue;
   

   process(){
    switch(this.operand){
      case "+":
        this.result = this.firstValue + this.secondValue;
        break;        
      case "-":
        this.result = this.firstValue - this.secondValue;
        break;
      case "X":
        this.result = this.firstValue * this.secondValue;
        break;
      case "/":
        this.result = this.firstValue / this.secondValue;
        break;
    }     
  }
   

}
