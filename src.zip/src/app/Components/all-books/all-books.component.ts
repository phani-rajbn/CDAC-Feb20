import { Component, OnInit } from '@angular/core';
import { Book } from '../../Entities/book'; //import a class or another component reference in ur code....

@Component({
  selector: 'app-all-books',
  templateUrl: './all-books.component.html',
  styleUrls: ['./all-books.component.css']
})

//The Behavior and the Data of the Component that U wish to display in the Main Page..
export class AllBooksComponent implements OnInit {

  public bookList : Book [];
  public selectedBook : Book;
  index : number = 0;
  newBook : Book;
  mySearch : string = "";
  price : number;
  constructor() { }

  ngOnInit(): void {
    this.bookList = [
      new Book(123, "2 States", 560),
      new Book(124, "The Ramayan", 360),
      new Book(125, "The Mahabharatha", 600),
      new Book(126, "Scientific Research in Ancient India", 1500)
    ];
  }

  //actual adding will happen here...
  addNewBook(bk : Book){
    this.bookList.push(bk);
    console.log("Book added to the database");
  }

  find(id: number){
    this.selectedBook = this.bookList.find((bk)=>bk.bookID == id);
  }

  //event handler for button
  
}
