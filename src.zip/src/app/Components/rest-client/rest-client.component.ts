import { Component, OnInit } from '@angular/core';
import { EmployeeRestService } from '../../Services/employee-rest.service'
import { Employee } from 'src/app/Entities/employee';
@Component({
  selector: 'app-rest-client',
  templateUrl: './rest-client.component.html',
  styleUrls: ['./rest-client.component.css']
})
export class RestClientComponent implements OnInit {

  constructor(private myService : EmployeeRestService) { }
  public data : Employee [] = [];
  ngOnInit(): void {
    this.getAll();
  }
  
  getAll(){
    this.myService.responseFromREST.subscribe((data)=>{
      this.data = <Employee[]>data;
    });    
  }

  addRecord(){
    this.myService.addNewRecord(new Employee(444,"Sanjay Gupta", "Kanpur")).subscribe((res)=>{
      alert(res);
    });
  }

  updateRecord(){
    debugger;
    this.myService.updateRecord(new Employee(444, "Sanjay Agarwal", "Kanpur")).subscribe((res)=>{
      alert(res);
    })
  }
}
