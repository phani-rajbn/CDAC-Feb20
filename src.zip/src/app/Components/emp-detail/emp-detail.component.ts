import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-detail',
  templateUrl: './emp-detail.component.html',
  styleUrls: ['./emp-detail.component.css']
})
export class EmpDetailComponent implements OnInit {
  //data of UR component.....
  empId : number;
  empName : string ;
  empAddress : string;
  empSalary : number;
  
  //Function used to initialize the data of the Component...
  ngOnInit(): void {
    this.empId = 123;
    this.empName ="Phaniraj";
    this.empAddress ="Bangalore";
    this.empSalary =65000;
  }

}
