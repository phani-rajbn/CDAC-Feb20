import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Book } from 'src/app/Entities/book';


@Component({
  selector: 'app-new-book',
  templateUrl: './new-book.component.html',
  styleUrls: ['./new-book.component.css']
})
export class NewBookComponent implements OnInit {
  

  constructor() { }
  newBook: Book;
  id : number;
  title : string;
  price : number;
  @Output() onAdd : EventEmitter<Book> = new EventEmitter<Book>();
  @Output() myclick : EventEmitter<string> = new EventEmitter<string>();
  ngOnInit(): void {
  }

 //event handler for the Button click
  addBook(){
    this.newBook = new Book(this.id, this.title, this.price);
    this.onAdd.emit(this.newBook);  
  }

  apple(){
    this.myclick.emit("Happy!!!!");
  }
}
