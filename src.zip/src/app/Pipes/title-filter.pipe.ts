import { Pipe, PipeTransform } from '@angular/core';
import { Book } from '../Entities/book';


@Pipe({
  name: 'titleFilter'
})
export class TitleFilterPipe implements PipeTransform {

  //Inputs, criteria,
  transform(allBooks: Book[], search :string ): Book[] {
    if(search == undefined) return allBooks;
    return allBooks.filter((bk) => bk.title.toLowerCase().includes(search.toLowerCase()));
  }

}
