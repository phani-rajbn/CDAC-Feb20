import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from '../app.component';
import { CalcComponent } from '../Components/calc/calc.component';
import { AllBooksComponent } from '../Components/all-books/all-books.component';
import { RestClientComponent } from '../Components/rest-client/rest-client.component';
import { BookDetailComponent } from '../Components/book-detail/book-detail.component';

//Module in Angular is a class that can contain a executable code that loads other components and modules to make up ur application. 
//By default one appModule will be created by the Angular..
//If U want hyperlinks in ur program and should be reprensented in a human readable manner, it is called as Routing. 

const routes : Routes =[
{
  path:'',
  pathMatch :"full",
  redirectTo: 'home'
},
{
  path : 'home',
  component : AppComponent
},
{
  path:"calc",
  component:CalcComponent
},
{
  path : "bookstore",
  component: AllBooksComponent,
  children:[
    {
      path : "details",
      component:BookDetailComponent
    }
  ]
},
{
  path : 'rest',
  component : RestClientComponent
}

]

@NgModule({
  declarations: [],
  imports: [
    CommonModule, 
    RouterModule.forRoot(routes)
  ],
  exports :[RouterModule]
})
export class RoutingModule { }
