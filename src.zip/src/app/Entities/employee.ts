export class Employee {
    empid : number;
    empName:string;
    empAddress:string

    constructor(id: number, ename : string, address : string) {
        this.empid = id;
        this.empName = ename;
        this.empAddress = address;
    }
}
