//U create classes to represent real world entities. 
export class Book {
    bookID : number;
    title : string;
    price : number;

    /**
     *Constructor of the Class...
     */
    constructor(id: number, title : string, cost : number) {
        this.bookID = id;
        this.title = title;
        this.price = cost;        
    }
}
