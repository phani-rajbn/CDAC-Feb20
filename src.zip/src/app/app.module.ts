import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RoutingModule } from '../app/routing/routing.module';

import { AppComponent } from './app.component';
import { CalcComponent } from './Components/calc/calc.component';
import { EmpDetailComponent } from './Components/emp-detail/emp-detail.component';
import { AllBooksComponent } from './Components/all-books/all-books.component';
import { BookDetailComponent } from './Components/book-detail/book-detail.component';
import { NewBookComponent } from './Components/new-book/new-book.component';
import { TitleFilterPipe } from './Pipes/title-filter.pipe';
import { RestClientComponent } from './Components/rest-client/rest-client.component';
import { EmployeeRestService } from './Services/employee-rest.service';
import { Employee } from './Entities/employee';
@NgModule({
  declarations: [
    AppComponent,
    CalcComponent,
    EmpDetailComponent,
    AllBooksComponent,
    BookDetailComponent,
    NewBookComponent,
    TitleFilterPipe,
    RestClientComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RoutingModule
  ],

  providers: [ EmployeeRestService],
  //bootstrap: [AllBooksComponent, AppComponent, RestClientComponent]//Component to execute when the Module is loaded into the memory of the Browser/..
  bootstrap :[AppComponent]
})
export class AppModule { }
