import { Component } from '@angular/core';

@Component({
  selector: 'app-Main',//tagname of UR component....
  templateUrl: './myFile.html',// html of ur component.
  styleUrls : ["./myComponentstyle.css"]
})
export class AppComponent {
  title = 'Training on Angular in CDAC';//data of the component(MODEL)

  clickMe(){
    alert("I was clicked");
  }  
}
/*
Component has:
Code file of ts which contains the functions and the data to present.
HTML file that contains the view of the Component represented as templateUrl.
CSS file: Defines the style for the html elements of UR component. 
spec.ts: Unit testing code for UR functions.
*/
