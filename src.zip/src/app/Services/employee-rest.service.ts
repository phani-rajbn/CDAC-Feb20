import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Employee } from '../Entities/employee';


//This Angular service will behave like a client object which calls all the REST services from here...
//There is a module called HttpClient module that will allow Angular Applications to access the REST services using Ajax. 
@Injectable({
  providedIn: 'root'
})

export class EmployeeRestService{
  //declare a parameter as private inside a constructor, its object is accessible within the class....

  private url : string = "http://localhost:1234/Employees";
  responseFromREST : any ;//Any means similar to var is JS or void* in C++...
  constructor(private hc : HttpClient) {   
    this.getAllEmployees();
  }

  getAllEmployees(){
    this.responseFromREST = this.hc.get(this.url);
  }

  addNewRecord(empToInsert : Employee) : any{
    // let json = JSON.stringify(empToInsert);
    let headers = new HttpHeaders({"Content-Type" : "application/json" });
    //let options = new RequestOptions({"headers" : headers});
    return this.hc.post(this.url, empToInsert, { "headers" : headers});
  }

  updateRecord(empToUpdate: Employee) : any{
    let headers = new HttpHeaders({"Content-Type" : "application/json" });
    debugger;
    let detail =  this.hc.put(this.url, empToUpdate, { "headers" : headers});
    return detail;
  }
  
}
